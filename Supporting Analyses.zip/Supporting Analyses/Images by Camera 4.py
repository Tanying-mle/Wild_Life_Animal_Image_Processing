# Databricks notebook source
#set variables
manifest_table=f"{schema}.remote_cameras.{process_name}_manifest_{photo_year}"

# COMMAND ----------

# import the 2.5 million images
df = spark.sql(f"select image_path from {manifest_table}")

# COMMAND ----------

# identify all the images taken by camera 4
df_camera4 = df.filter(df.image_path.contains("Camera 4"))

df_camera4 = df_camera4.withColumn(
    "image_path",
    F.regexp_replace("image_path", r"^dbfs:", "")
)

# COMMAND ----------

df_camera4.count()

# COMMAND ----------

# 14% images were taken by camera 4
df_camera4.count()/df.count()

# COMMAND ----------

# #load model resutls from megadetectorv6-yolo9c
# df5a=spark.sql(f"select * from {mg5a_output_table}")

# #load model resutls from megadetectorv6-yolo9c
# df9c=spark.sql(f"select * from {yolo9c_output_table}")

#load model resutls from megadetectorv6-yolo9c
df5a=spark.sql("select * from meadowbank_prod.remote_cameras.md24_tws_model_results_mg5a")

#load model resutls from megadetectorv6-yolo9c
df9c=spark.sql("select * from meadowbank_prod.remote_cameras.md24_tws_model_results_yolo9c")

#print table count, should be the same, both 1279878 rows
#print(df5a.count(),df9c.count())

# COMMAND ----------

from pyspark.sql.functions import col, from_json, explode
from pyspark.sql.types import *

# JSON schema for your structure
schema = StructType([
    StructField("file", StringType()),
    StructField("max_detection_conf", DoubleType()),
    StructField("detections", ArrayType(
        StructType([
            StructField("category", StringType()),
            StructField("conf", DoubleType()),
            StructField("bbox", ArrayType(DoubleType()))
        ])
    ))
])

# Parse JSON column  #1279878 rows
df5a_parsed = df5a.withColumn("parsed", from_json(col("json_output"), schema))

# Extract top-level fields #1279878 rows
df5a_top = df5a_parsed.select(
    col("image_path").alias("image_path"),
    col("parsed.max_detection_conf").alias("max_detection_conf"),
    col("parsed.detections").alias("detections")
)

# Explode detections array (handles ANY length) only 811299 left
df5a_exploded = df5a_top.withColumn("det", explode("detections"))

# Extract per-detection fields
df5a_final = df5a_exploded.select(
    "image_path",
    col("det.category").alias("detection_category_5a"),
    col("det.conf").alias("detection_conf_5a"),
    col("det.bbox").alias("detection_bbox_5a")
)

# df5a_final.show(3,truncate=False)

# COMMAND ----------

from pyspark.sql.functions import col, from_json, explode
from pyspark.sql.types import *

# JSON schema for your structure
schema = StructType([
    StructField("file", StringType()),
    StructField("max_detection_conf", DoubleType()),
    StructField("detections", ArrayType(
        StructType([
            StructField("category", StringType()),
            StructField("conf", DoubleType()),
            StructField("bbox", ArrayType(DoubleType()))
        ])
    ))
])

# Parse JSON column
df9c_parsed = df9c.withColumn("parsed", from_json(col("json_output"), schema))

# Extract top-level fields
df9c_top = df9c_parsed.select(
    col("image_path").alias("image_path"),
    col("parsed.max_detection_conf").alias("max_detection_conf"),
    col("parsed.detections").alias("detections")
)

# Explode detections array (handles ANY length)
df9c_exploded = df9c_top.withColumn("det", explode("detections"))

# Extract per-detection fields
df9c_final = df9c_exploded.select(
    "image_path",
    col("det.category").alias("detection_category_9c"),
    col("det.conf").alias("detection_conf_9c"),
    col("det.bbox").alias("detection_bbox_9c")
)

# df9c_final.show(3,truncate=False)

# COMMAND ----------

# Rename columns to avoid conflicts
a = df5a_final.select(
    col("image_path"),
    col("detection_category_5a").alias("category"),
    col("detection_conf_5a").alias("conf_md5a"),
    col("detection_bbox_5a").alias("bbox_md5a")
)

# Rename columns to avoid conflicts
b = df9c_final.select(
    col("image_path"),
    col("detection_category_9c").alias("category"),
    col("detection_conf_9c").alias("conf_md9c"),
    col("detection_bbox_9c").alias("bbox_md9c")
)

# Full Outer Join to keep All rows from both df5a_final and df9c_final
df = (
    a.join(
        b,
        on=["image_path", "category"],
        how="full"
    )
)

# show top 3 rows without truncating
df.show(3, truncate=False)

# COMMAND ----------

import pyspark.sql.functions as F

df_very_confident = df.filter((F.col("category") == "1") & ((F.col("conf_md5a") >= 0.5) & (F.col("conf_md9c") >= 0.5)))
df_very_confident.count()

df_joined = df_camera4.join(
    df_very_confident,
    on="image_path",
    how="inner"
)

df_joined.count()

# COMMAND ----------

from pyspark.sql import functions as F

thresholds = [0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2]

results = []

for t in thresholds:
    print(f"Processing threshold {t} ...")
    
    # Step 1: filter df based on threshold
    df_filtered = df.filter(
        (F.col("category") == "1") &
        (F.col("conf_md5a") >= t) &
        (F.col("conf_md9c") >= t)
    )
    
    # Step 2: inner join with df_camera4
    df_joined = df_camera4.join(
        df_filtered,
        on="image_path",
        how="inner"
    )
    
    # Step 3: count rows
    joined_count = df_joined.count()
    
    results.append((t, joined_count))

# Convert to Spark DataFrame (optional)
df_results = spark.createDataFrame(results, ["threshold", "joined_count"])
df_results.show()

# COMMAND ----------

df_joined = df_camera4.join(
    df_very_confident,
    on="image_path",
    how="inner"
)


# COMMAND ----------

df_joined.count()

# COMMAND ----------

df_very_confident.count()

# COMMAND ----------

import os
import random
from PIL import Image
import matplotlib.pyplot as plt

def show_images_grid(image_paths, ncols=5, figsize=(20, 12), resize_to=600):
    """
    Display images in a grid with automatic resizing to avoid output size overflow.
    """
    n_images = len(image_paths)
    nrows = (n_images + ncols - 1) // ncols
    
    plt.figure(figsize=figsize)

    for i, path in enumerate(image_paths, 1):
        try:
            img = Image.open(path)

            # Resize to keep Databricks output small (prevents 20MB overflow)
            img.thumbnail((resize_to, resize_to))

            plt.subplot(nrows, ncols, i)
            plt.imshow(img)
            plt.axis("off")
            plt.title(os.path.basename(path), fontsize=10)
        except Exception as e:
            print(f"⚠️ Error loading {path}: {e}")

    plt.tight_layout()
    plt.show()



# COMMAND ----------

# show images in batches as we have 100 images and can only see 10 images per batch

def show_images_in_batches(image_list, batch_size=10):
    total = len(image_list)
    print(f"📸 Total images: {total}, showing {batch_size} per batch")

    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)
        batch = image_list[start:end]

        print(f"\n➡️ Showing images {start+1} to {end} ...")

        show_images_grid(
            batch,
            ncols=5,             # 5 columns per row
            figsize=(20, 12),    # enlarge layout
            resize_to=600        # bigger images
        )

# COMMAND ----------

# show images with 10 images per batch
image_list = [r.image_path for r in df_joined.select("image_path").collect()]

# Randomly pick 10 images
sampled_images = random.sample(image_list, min(100, len(image_list)))

show_images_in_batches(sampled_images)

# COMMAND ----------

