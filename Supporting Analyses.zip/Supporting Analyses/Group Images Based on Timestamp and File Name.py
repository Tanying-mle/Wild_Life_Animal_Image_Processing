# Databricks notebook source
# define the year of photoes for table names
photo_year="2024"

# schema of the output
schema= "meadowbank_prod"

# define output of this model's name and location, ex. md24v6 then final table will be 
process_name="md24_tws"

# Volume root path
volume_root = "/Volumes/meadowbank_prod/remote_cameras/mbk_remote_cameras_blob/2024/"

# designated folder for animal output images
output_uc_folder="/Volumes/meadowbank_prod/remote_cameras/mbk_remote_cameras_blob/results/2024_TWS/wildlife_test/"

# includes timestamp
manifest_timestamp_table=f"{schema}.remote_cameras.manifest_timestamp_{photo_year}"

# model output table includes model output from both models
model_output_table=f"{schema}.remote_cameras.{process_name}_megadetector_v5a_v6byolo9c_results_{photo_year}"

# add event_id to same animals/vehicles taken by multiple photoes
manfiest_table_grouped=f"{schema}.remote_cameras.{process_name}_event_id_{photo_year}"

# manifest final output table for final_category to classify images
animal_confidence_threshold=0.5
vehicle_confidence_threshold=0.3
human_confidence_threshold=0.3

# COMMAND ----------

#Extract sequence number from image_path
from pyspark.sql import functions as F
from pyspark.sql import Window

def group_by_filename_and_time(df, time_threshold=5):

    df1 = df.withColumn(
        "seq",
        F.regexp_extract("image_path", r"(\d+)\.JPG$", 1).cast("int")
    )

    df1 = df1.withColumn(
    "camera_id",
    F.regexp_extract("image_path", r"/Camera (\d+)", 1)
    )


    # Construct full timestamp
    df1 = df1.withColumn(
        "full_ts",
        F.to_timestamp(F.concat_ws(" ", "capture_date", "timestamp"))
    )

    w = Window.partitionBy("camera_id", "capture_date").orderBy("seq")

    df2 = (
        df1
        .withColumn("prev_seq", F.lag("seq").over(w))
        .withColumn("seq_gap", F.col("seq") - F.col("prev_seq"))
        .withColumn("prev_full_ts", F.lag("full_ts").over(w))
        .withColumn("time_gap", F.unix_timestamp("full_ts") - F.unix_timestamp("prev_full_ts"))
    )

    df3 = df2.withColumn(
        "new_group_flag",
        F.when((F.col("seq_gap") > 1) | (F.col("time_gap") > time_threshold), 1).otherwise(0)
    )

    df_grouped = df3.withColumn(
        "group_id",
        F.sum("new_group_flag").over(
            w.rowsBetween(Window.unboundedPreceding, Window.currentRow)
        )
    )

    return df_grouped



# COMMAND ----------

#group images by file name and timestamp extracted from the individual images
df_ts = spark.sql("select * from meadowbank_prod.remote_cameras.md24_tws_manifest_timestamp")

df_ts = df_ts.withColumn(
    "TM_flag",
    F.when(F.col("timestamp").endswith("0:00"), "T").otherwise("M")
)

df_ts = df_ts.withColumnRenamed("path", "image_path")

df_grouped = group_by_filename_and_time(df_ts)

# COMMAND ----------

#import model output table
df=spark.sql(f"select * from {model_output_table}")

# COMMAND ----------

import pyspark.sql.functions as F

#threshold 0.5 was used here 
df_very_confident = df.join(df_ts, on="image_path", how="inner").filter(F.col("TM_flag") != "T")\
    .filter((F.col("category") == "1") & ((F.col("conf_md5a") >= animal_confidence_threshold) & (F.col("conf_md9c") >= animal_confidence_threshold)))

# identify all the images taken by camera 4
df_very_confident = df_very_confident.withColumn(
    "camera_folder",
    F.regexp_extract(F.col("image_path"), r"(Camera \d+)", 1)
)

# exclude all tagged images from camera 4
df_very_confident_no_camera4 = df_very_confident.filter(~F.col("image_path").contains("Camera 4"))

print("number of distinct images is: " + str(df_very_confident_no_camera4.select(F.countDistinct("image_path")).collect()[0][0]))

# COMMAND ----------

# Includes all image_path from df_animal, Looks up the matching event_id from df_grouped (same image_path)
# First join: animal → event_id
from pyspark.sql.functions import regexp_replace

df_grouped_clean = df_grouped.withColumn(
    "image_path",
    regexp_replace("image_path", "^dbfs:/", "/"))

df_a = (
    df_very_confident
        .join(
            df_grouped_clean.select("image_path", "camera_id", "group_id").alias("g"),
            on="image_path",
            how="inner"
        )
)

df_a = df_a.withColumnRenamed("image_path", "animal_image_path")

# Second join: get all images in that event_id
df_event_expanded = (
    df_grouped_clean.alias("g2")
        .join(
            df_a.alias("a"),
            on=["camera_id", "group_id"],
            how="inner"
        )
        .select(
            "g2.image_path",          # original animal image
            "camera_id",
            "group_id",
            "a.animal_image_path"          # related images
        )
        .withColumnRenamed("image_path", "related_image_path")
)



# COMMAND ----------

df_count = df_grouped.select("camera_id", "group_id").distinct().count()
print(df_count)

# COMMAND ----------

df_group_counts = (
    df_grouped.groupBy("camera_id", "group_id")
      .agg(F.countDistinct("image_path").alias("num_images"))
)

max_count = df_group_counts.agg(F.max("num_images")).collect()[0][0]
print(max_count)

df_max_groups = df_group_counts.filter(F.col("num_images") == max_count)


# COMMAND ----------

df_grouped.toPandas().head(5)

# COMMAND ----------

df_grouped.select(F.countDistinct("image_path").alias("distinct_image_count")).show()

# COMMAND ----------

df_result = (
    df_grouped
        .groupBy("group_id")
        .agg(F.countDistinct("image_path").alias("image_cnt"))
        .orderBy(F.col("image_cnt").desc())
)

df_result.show(truncate=False)


# COMMAND ----------

from pyspark.sql.functions import col

# Write manifest table with group info to Catalog Volume
df_grouped.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable(manfiest_table_grouped)

# COMMAND ----------

