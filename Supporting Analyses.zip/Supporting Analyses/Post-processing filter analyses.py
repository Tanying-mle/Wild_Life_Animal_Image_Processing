# Databricks notebook source
#import all the 18,177 images tagged by the model with both model threshold>=0.2
df=spark.sql("select * from meadowbank_prod.remote_cameras.md24v6_tws_low_threshold_tagged_images_18177")

# COMMAND ----------

import pyspark.sql.functions as F

print("number of distinct images is: " + str(df.select(F.countDistinct("image_path")).collect()[0][0]))

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# 1️⃣ Extract folder + filename + numeric sequence
df_parsed = (
    df
    .withColumn("folder", F.regexp_replace("image_path", "/[^/]+$", ""))
    .withColumn("file_name", F.regexp_extract("image_path", "[^/]+$", 0))
    .withColumn(
        "seq_num",
        F.regexp_extract("file_name", r"(\d+)(?=\.[^.]+$)", 1).cast("int")
    )
)

# 2️⃣ Window sorted within each folder
w = Window.partitionBy("folder").orderBy("seq_num")

# 3️⃣ Compute previous and next sequence numbers
df_with_neighbors = (
    df_parsed
    .withColumn("prev_seq", F.lag("seq_num").over(w))
    .withColumn("next_seq", F.lead("seq_num").over(w))
)

# 4️⃣ Identify rows that have seq-1 or seq+1 in the same folder
df_adjacent = df_with_neighbors.filter(
    (F.col("prev_seq") == F.col("seq_num") - 1) |
    (F.col("next_seq") == F.col("seq_num") + 1)
)

# 5️⃣ Select only the image paths (unique)
df_adjacent_images = df_adjacent.select("image_path").distinct()

df_adjacent_images.orderBy("image_path").show(truncate=False)

print("Total images with adjacent neighbor:", df_adjacent_images.count())


# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import Window

df2 = df_adjacent.withColumn(
    "seq_num",
    F.regexp_extract("image_path", r"RCNX(\d+)", 1).cast("int")
)

w = Window.partitionBy("folder").orderBy("seq_num")

df_pairs = (
    df2
        .withColumn("prev_image_path", F.lag("image_path").over(w))
        .withColumn("prev_seq", F.lag("seq_num").over(w))
)

df_adjacent = df_pairs.filter(
    (F.col("prev_seq").isNotNull()) &
    (F.col("seq_num") == F.col("prev_seq") + 1)
)

# COMMAND ----------

df_adjacent.count()

# COMMAND ----------

df_adjacent.select("image_path","prev_image_path").show(5,truncate=False)

# COMMAND ----------

# from pyspark.sql import functions as F
# from pyspark.sql.window import Window

# # split path into parts
# df1 = df_adjacent.withColumn("parts", F.split("image_path", "/"))

# # detect RECNX folder (like 100RECNX, 101RECNX)
# df2 = df1.withColumn(
#     "burst_folder",
#     F.when(
#         F.col("parts").getItem(F.size("parts")-2).rlike("^[A-Za-z]*\\d+[A-Za-z]*$"),
#         # Case B: has RECNX-like folder -> use LAST TWO FOLDERS
#         F.concat(
#             F.col("parts").getItem(F.size("parts")-3), F.lit("/"),
#             F.col("parts").getItem(F.size("parts")-2)
#         )
#     ).otherwise(
#         # Case A: only date folder -> use ONLY the date folder
#         F.col("parts").getItem(F.size("parts")-2)
#     )
# )

# # extract filename
# df3 = df2.withColumn("file_name", F.regexp_extract("image_path", r"([^/]+)$", 1))

# # extract seq_num
# df4 = df3.withColumn("seq_num", F.regexp_extract("file_name", r"(\d+)", 1).cast("int"))

# # sort by folder + seq
# df4 = df4.orderBy("burst_folder", "seq_num")

# # lag
# w = Window.partitionBy("burst_folder").orderBy("seq_num")
# df5 = df4.withColumn("prev_seq", F.lag("seq_num").over(w))

# # detect new groups
# df6 = df5.withColumn(
#     "is_new_group",
#     F.when((F.col("prev_seq").isNull()) | (F.col("seq_num") != F.col("prev_seq") + 1), 1).otherwise(0)
# )

# # local_id
# df7 = df6.withColumn("local_group_id", F.sum("is_new_group").over(w))

# # UNIQUE burst groups
# unique_groups = df7.select("burst_folder", "local_group_id").distinct().orderBy("burst_folder", "local_group_id")

# # assign global incremental group_id
# wg = Window.orderBy("burst_folder", "local_group_id")
# unique_groups2 = unique_groups.withColumn("global_group_id", F.row_number().over(wg))

# # final join
# df_final = df7.join(unique_groups2, ["burst_folder", "local_group_id"], "left")

# COMMAND ----------

# MAGIC %pip install opencv-python

# COMMAND ----------

from pyspark.sql.functions import udf
from pyspark.sql.types import DoubleType
import cv2

@udf(DoubleType())
def motion_score(curr, prev):
    if prev is None:
        return None

    img1 = cv2.imread(curr, cv2.IMREAD_GRAYSCALE)
    img2 = cv2.imread(prev, cv2.IMREAD_GRAYSCALE)

    if img1 is None or img2 is None:
        return None

    img1 = cv2.resize(img1, (256, 256))
    img2 = cv2.resize(img2, (256, 256))

    diff = cv2.absdiff(img1, img2)
    return float(diff.mean()) / 255.0


# COMMAND ----------

df_motion = df_adjacent.withColumn(
    "motion_score",
    motion_score(F.col("image_path"), F.col("prev_image_path"))
)


# COMMAND ----------

df_motion.show(5,truncate=False)

# COMMAND ----------

df_motion_count = (
    df_motion
        .select("image_path")
        .distinct()
        .count()
)

print("Number of unique images in df_motion is:", df_motion_count)

# COMMAND ----------

from pyspark.sql import functions as F

df_motion.agg(F.max("motion_score").alias("max_motion_score")).show()

# COMMAND ----------

df_motion.orderBy(F.col("motion_score").desc()).show(10, truncate=False)

# COMMAND ----------

STATIC_THRESHOLD = 0.02

df_static = df_motion.filter(
    (F.col("motion_score") < STATIC_THRESHOLD) &
    (F.col("conf_md5a") < 0.5) &
    (F.col("conf_md9c") < 0.5)
)

df_not_static = df_motion.join(
    df_static.select("image_path"),
    on=["image_path"],
    how="left_anti"
)

# COMMAND ----------

print("static dataframe count is: ",df_static.count()) #23178
print("nonstatic dataframe count is: ",df_non_static.count())

# COMMAND ----------

static_flat_list = (
    df_static
        .select("image_path", "prev_image_path")
        .withColumn("pair", F.array("image_path", "prev_image_path"))
        .select(F.explode("pair").alias("img"))
        .toPandas()["img"]
        .tolist()
)


# COMMAND ----------

static_flat_list[:10]

# COMMAND ----------

dedup_static_list = list(dict.fromkeys(static_flat_list))
len(dedup_static_list)

# COMMAND ----------

dedup_nonstatic_list = list(dict.fromkeys(nonstatic_flat_list))
len(dedup_nonstatic_list)

# COMMAND ----------

common = list(set(dedup_static_list) & set(dedup_nonstatic_list))
len(common)

# COMMAND ----------

from pyspark.sql import functions as F

rows = (
    df_static
        .select("image_path")
        .distinct()              # <-- deduplicate
        .orderBy("image_path")   # <-- sorted
        .limit(100)              # <-- first 100
        .collect()
)

static_image_list = [row.image_path for row in rows]


# COMMAND ----------

import os
import random
from PIL import Image
import matplotlib.pyplot as plt

def show_images_grid(image_paths, ncols=5, figsize=(20, 12), resize_to=600):
    """
    Display images in a grid with automatic resizing to avoid output size overflow.
    """
    n_images = len(image_paths)
    nrows = (n_images + ncols - 1) // ncols
    
    plt.figure(figsize=figsize)

    for i, path in enumerate(image_paths, 1):
        try:
            img = Image.open(path)

            # Resize to keep Databricks output small (prevents 20MB overflow)
            img.thumbnail((resize_to, resize_to))

            plt.subplot(nrows, ncols, i)
            plt.imshow(img)
            plt.axis("off")
            plt.title(os.path.basename(path), fontsize=10)
        except Exception as e:
            print(f"⚠️ Error loading {path}: {e}")

    plt.tight_layout()
    plt.show()



# COMMAND ----------

# show images in batches as we have 100 images and can only see 10 images per batch

def show_images_in_batches(image_list, batch_size=10):
    total = len(image_list)
    print(f"📸 Total images: {total}, showing {batch_size} per batch")

    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)
        batch = image_list[start:end]

        print(f"\n➡️ Showing images {start+1} to {end} ...")

        show_images_grid(
            batch,
            ncols=5,             # 5 columns per row
            figsize=(20, 12),    # enlarge layout
            resize_to=600        # bigger images
        )

# COMMAND ----------

# show image in batches for quick validation
show_images_in_batches(static_image_list)

# COMMAND ----------

from pyspark.sql import functions as F

rows = (
    df_non_static
        .select("image_path")
        .orderBy("image_path")
        .limit(100)
        .collect()
)

non_static_image_list = [row.image_path for row in rows]

# COMMAND ----------

nonstatic_flat_list = (
    df_non_static
        .select("image_path", "prev_image_path")
        .withColumn("pair", F.array("image_path", "prev_image_path"))
        .select(F.explode("pair").alias("img"))
        .toPandas()["img"]
        .tolist()
)

# COMMAND ----------

# show image in batches for quick validation with confidence<=0.5
show_images_in_batches(non_static_image_list)

# COMMAND ----------

# show image in batches for quick validation WITHOUT confidence<=0.5
show_images_in_batches(non_static_image_list)

# COMMAND ----------

#exclude rows from df where image_path is in static_image_list
df_filtered = df.filter(~F.col("image_path").isin(dedup_static_list))

# show images with 100 images per batch
image_list = [r.image_path for r in df_filtered.select("image_path").collect()]

# Randomly pick 100 images
sampled_images = random.sample(image_list, min(100, len(image_list)))

# show image in batches for quick validation
show_images_in_batches(sampled_images)

# COMMAND ----------

df_export = pd.DataFrame({
    "image_path": sampled_images,
    "contains_animals": [""] * len(sampled_images)
})

df_export.to_csv(f"/dbfs/FileStore/manual_validation_exclude_static.csv", index=False)

# COMMAND ----------

# download the CSV file to your local machine
displayHTML(f'<a href="/files/manual_validation_exclude_static.csv" download>Click to download CSV</a>')

# COMMAND ----------

from pyspark.sql.functions import countDistinct
print(df_filtered.select(countDistinct("image_path")).collect()[0][0])


# COMMAND ----------

# show images with 100 images per batch
image_list = [r.image_path for r in df.select("image_path").collect()]

# Randomly pick 100 images
sampled_images = random.sample(image_list, min(100, len(image_list)))

# show image in batches for quick validation
show_images_in_batches(sampled_images)

# COMMAND ----------

df_export = pd.DataFrame({
    "image_path": sampled_images,
    "contains_animals": [""] * len(sampled_images)
})

df_export.to_csv(f"/dbfs/FileStore/manual_validation.csv", index=False)

# COMMAND ----------

# download the CSV file to your local machine
displayHTML(f'<a href="/files/manual_validation.csv" download>Click to download CSV</a>')

# COMMAND ----------

